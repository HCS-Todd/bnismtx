﻿This bundle includes all sponsor logos referenced by the site.

- actual-files/ contains image files available in this workspace.
- remote-logo-links/ contains .url shortcuts for remote logos used by the site.
- logo-manifest.csv lists every logo, suggested filename, type, and source URL.
- logo-gallery.html shows the logos when opened on a machine with internet access.

Note: this Codex shell could not directly connect to GitHub or Google to download remote images, so remote favicon logos are included as source links rather than copied image binaries.
